#------------------------------------------------------------------------------
# Copyright (C) 2010 Richard Lincoln
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#------------------------------------------------------------------------------

""" Simulates energy trade in a power system.
"""

#------------------------------------------------------------------------------
#  Imports:
#------------------------------------------------------------------------------

import sys
import optparse

from os.path import dirname, join

from numpy import array

from pybrain.tools.shortcuts import buildNetwork
from pybrain.rl.agents import LearningAgent
from pybrain.rl.learners import ENAC
from pybrain.structure.modules import SigmoidLayer

from pylon import Case, Bus, Generator
from pylon import OPF

from pylon.main import read_case

from pylon.readwrite import MATPOWERReader, ReSTWriter

from pyreto.environment import ContinuousMarketEnvironment
from pyreto.experiment import MarketExperiment
from pyreto.task import EpisodicProfitTask
from pyreto.smart_market import SmartMarket
from pyreto.tools import ReSTExperimentWriter

#------------------------------------------------------------------------------
#  "PyretoApplication" class:
#------------------------------------------------------------------------------

class PyretoApplication(object):
    """ Simulates energy trade in a power system.
    """

    def __init__(self, fileName="", type="any", interactions=24, ac=False):
        """ Initialises a new PyretoApplication instance.
        """
        # Name of the input file.
        self.fileName = fileName

        # Format in which the case is stored.  Possible values are: 'any',
        # 'matpower', 'psat', 'matlab' and 'psse'.
        self.type = type

        # Number of interactions to perform.
        self.interactions = interactions

        # Use AC OPF routine?
        self.ac = ac

    #--------------------------------------------------------------------------
    #  Runs the application:
    #--------------------------------------------------------------------------

    def run(self, input, output):
        """ Forms a case from the input, associates an agent with each
            generator, performs the specified number of interactions and
            writes a report to the output.
        """
        # Get the case from the input.
        case = read_case(input, self.type, self.fileName)

        experiment = buildExperiment(case)

        experiment.doInteractions(self.interactions)

        writer = ReSTExperimentWriter()
        writer(experiment, output)

#------------------------------------------------------------------------------
#  Associate one agent with each generator in the network:
#------------------------------------------------------------------------------

def buildExperiment(case):
    """ Associates an agent and a task with each generator in the network.
    """
    mkt = SmartMarket(case)
    experiment = MarketExperiment([], [], mkt)

    for generator in mkt.case.online_generators:
        # Create the world in which the trading agent acts.
        env = ContinuousMarketEnvironment(asset=generator, market=mkt)

        # Create a task that connects each agent to it's environment. The task
        # defines what the goal is for an agent and how the agent is rewarded
        # for it's actions.
        task = EpisodicProfitTask(env)

        # Create a linear controller network. Each agent needs a controller
        # that maps the current state to an action.
#        net = buildNetwork( 3, 6, 1, bias = False, outclass = SigmoidLayer )
        net = buildNetwork(1, 1, bias=False)

        net._setParameters(array([0.5]))

        # Create agent. The agent is where the learning happens. For continuous
        # problems a policy gradient agent is required.  Each agent has a
        # module (network) and a learner, that modifies the module.
#        agent = LearningAgent( module = net, learner = ENAC() )
#        agent.name = "LearningAgent-%s" % generator.name
        agent = LearningAgent(module=net, learner=ENAC())
        agent.name = "PolicyGradientAgent-%s" % generator.name

        # Backpropagation parameters.
#        gradientDescent = agent.learner.gd
        # Learning rate (0.1-0.001, down to 1e-7 for RNNs).
        agent.alpha = 0.1

        # Alpha decay (0.999; 1.0 = disabled).
#        gradientDescent.alphadecay = 1.0
#
#        # momentum parameters (0.1 or 0.9)
#        gradientDescent.momentum = 0.0
#        gradientDescent.momentumvector = None
#
#        # --- RProp parameters ---
#        gradientDescent.rprop = False
#        # maximum step width (1 - 20)
#        gradientDescent.deltamax = 5.0
#        # minimum step width (0.01 - 1e-6)
#        gradientDescent.deltamin = 0.01

        # Collect tasks and agents.
        experiment.tasks.append(task)
        experiment.agents.append(agent)

    return experiment

#------------------------------------------------------------------------------
#  Pyreto entry point:
#------------------------------------------------------------------------------

def main():
    """ Defines the entry point for Pyreto.
    """
    parser = optparse.OptionParser("usage: pyreto [options] input_file")

    parser.add_option("-o", "--output", dest="output", metavar="FILE",
        help="Write report to FILE.")

    parser.add_option("-t", "--input-type", dest="type", metavar="TYPE",
        default="any", help="The argument following the -t is used to "
        "indicate the format type of the input data file. The types which are "
        "currently supported include: matpower, psat, psse.  If not "
        "specified Pyreto will attempt to determine the type according to the "
        "file name extension and the file header.")

    parser.add_option("-n", "--interactions", dest="interactions",
        metavar="INTERACTIONS", default=24, help="The argument following the "
        "-n is used to set the number of interactions between agents that "
        "will be performed before returning the report.")

    parser.add_option("--ac", dest="ac", default=False,
        help="Use AC OPF routine.")

    parser.add_option("-q", "--quiet", action="store_true", dest="quiet",
        default=False, help="Print less information.")

    parser.add_option("-d", "--debug", action="store_true", dest="debug",
        default=False, help="Print debug information.")

    (options, args) = parser.parse_args()

    if options.quiet:
        logger.setLevel(logging.CRITICAL)
    elif options.debug:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    # Output.
    if options.output:
        outfile = options.output
        if outfile == "-":
            outfile = sys.stdout
            logger.setLevel(logging.CRITICAL) # we must stay quiet

    else:
        outfile = sys.stdout

    # Input.
    if len(args) > 1:
        parser.print_help()
        sys.exit(1)

    elif len(args) == 0 or args[0] == "-":
        filename = ""
        if sys.stdin.isatty():
            # True if the file is connected to a tty device, and False
            # otherwise (pipeline or file redirection).
            parser.print_help()
            sys.exit(1)
        else:
            # Handle piped input ($ cat ehv3.raw | pylon | rst2pdf -o ans.pdf).
            infile = sys.stdin

    else:
        filename = args[0]
        infile   = open(filename)

    pyreto = PyretoApplication(fileName=filename, type=options.type,
        interactions=options.interactions, ac=options.ac)

    # Call the Pyreto application.
    pyreto(infile, outfile)

    try:
        infile.close() # Clean-up
    except:
        pass


if __name__ == "__main__":
    import logging
    logger = logging.getLogger()

    # Remove PyBrain handlers.
    for handler in logger.handlers:
        logger.removeHandler(handler)

    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    main()

# EOF -------------------------------------------------------------------------
